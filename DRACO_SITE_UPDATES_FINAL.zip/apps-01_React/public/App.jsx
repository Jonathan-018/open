function App() {
  document.title = "DeimusTech Engineering Operations";
  const systems = [
    { name: 'edge-fw-01', role: 'Edge Firewall', ip: '192.168.100.2', zone: 'EDGE', status: 'Operational' },
    { name: 'portal-01', role: 'External Portal', ip: '192.168.150.10', zone: 'DMZ', status: 'Operational' },
    { name: 'dc01', role: 'Domain Controller / DNS', ip: '192.168.200.10', zone: 'LAN', status: 'Operational' },
    { name: 'ca01', role: 'Certificate Authority', ip: '192.168.200.20', zone: 'LAN', status: 'Operational' },
    { name: 'apps-01', role: 'Application Services', ip: '192.168.200.44', zone: 'LAN', status: 'Operational' },
    { name: 'wks-01', role: 'Windows 11 Workstation', ip: '192.168.200.101', zone: 'LAN', status: 'Operational' },
    { name: 'wks-02', role: 'Windows 10 Workstation', ip: '192.168.200.102', zone: 'LAN', status: 'Operational' },
    { name: 'ws-eng-01', role: 'CentOS Engineering Workstation', ip: '192.168.200.103', zone: 'LAN', status: 'Operational' }
  ];

  const activity = [
    ['14:31:42', 'APPS-01', 'Application deployment completed (v2.4.1)', 'Info'],
    ['14:27:18', 'DC01', 'Directory synchronization completed', 'Info'],
    ['14:18:03', 'CA01', 'Certificate enrollment request processed', 'Info'],
    ['13:56:29', 'WS-ENG-01', 'Configuration baseline applied', 'Info'],
    ['13:42:11', 'PORTAL-01', 'External service health check passed', 'Info'],
    ['12:17:55', 'WKS-02', 'Windows updates installed', 'Info']
  ];

  const announcements = [
    ['blue', 'Platform 4.6 Released', 'New features and security enhancements are now available.', 'Sep 4, 2026'],
    ['yellow', 'Planned Maintenance', 'Customer Portal maintenance window: 02:00–06:00 UTC.', 'Sep 6, 2026'],
    ['green', 'Updated Access Requirements', 'New MFA and remote access policies are now in effect.', 'Aug 12, 2026'],
    ['blue', 'Engineering Change Process', 'Revised procedure for application deployments.', 'Jul 28, 2026']
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="side-brand">
          <div className="brand-mark"><span></span></div>
          <div>
            <div className="brand-name">DEIMUSTECH</div>
            <div className="brand-sub">ENGINEERING OPERATIONS</div>
          </div>
        </div>

        <nav className="side-nav">
          <a className="active" href="#dashboard"><span>⌂</span>Dashboard</a>
          <a href="#infrastructure"><span>▦</span>Infrastructure</a>
          <a href="#applications"><span>◇</span>Applications</a>
          <a href="#deployments"><span>⊕</span>Deployments</a>
          <a href="#logs"><span>▤</span>System Logs</a>
          <a href="#docs"><span>▣</span>Documentation</a>
          <a href="#network"><span>⌘</span>Network Tools</a>
          <a href="#utilities"><span>⚙</span>Utilities</a>
        </nav>

        <div className="restricted">
          <div className="restricted-title">🔒 INTERNAL USE ONLY</div>
          <p>This system is restricted to authorized DeimusTech personnel. Use of this system is monitored and subject to company policy.</p>
        </div>

        <div className="side-footer">
          <span>DEIMUSTECH</span><span>v2.4.1</span>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="portal-label">INTERNAL OPERATIONS PORTAL</div>
          <div className="top-links">
            <span>Systems</span><i></i><span>Infrastructure</span><i></i><span>Applications</span><i></i><span>Deployments</span><i></i><span>Logs</span><i></i><span>Documentation</span>
          </div>
          <div className="search">⌕ <span>Search systems, docs, or logs...</span></div>
        </header>

        <div className="content" id="dashboard">
          <section className="page-title">
            <div>
              <h1>Engineering Operations</h1>
              <p>Monitor. Manage. Deploy. Secure.</p>
            </div>
            <div className="motto">PEOPLE.<br/>TECHNOLOGY.<br/>RESILIENCE.</div>
          </section>

          <section className="metric-grid">
            <Metric icon="▤" number="8" title="Total Systems" detail="8 Online  |  0 Offline" tone="blue" />
            <Metric icon="◇" number="4" title="Core Applications" detail="4 Healthy  |  0 Degraded" tone="green" />
            <Metric icon="↻" number="2" title="Active Deployments" detail="1 Running  |  1 Scheduled" tone="blue" />
            <Metric icon="!" number="0" title="Critical Alerts" detail="0 Open  |  3 Resolved (24h)" tone="red" />
          </section>

          <section className="dashboard-grid">
            <div className="left-stack">
              <section className="panel infra-panel" id="infrastructure">
                <PanelHeader title="Enterprise Infrastructure" subtitle="DeimusTech Network Overview" action="View Details →" />
                <div className="network-map">
                  <div className="node external"><div className="node-icon globe">◎</div><b>External (Internet)</b><small>Internet</small></div>
                  <div className="connector c1"></div>
                  <div className="node edge"><div className="node-icon firewall">▦</div><b>edge-fw-01</b><small>192.168.100.2</small></div>
                  <div className="connector c2"></div>
                  <div className="branch"></div>

                  <div className="zone dmz-zone">
                    <span className="zone-label">DMZ</span>
                    <SystemNode name="portal-01" ip="192.168.150.10" type="server" />
                  </div>

                  <div className="zone lan-zone">
                    <span className="zone-label">Internal Network</span>
                    <div className="lan-row">
                      <SystemNode name="dc01" ip="192.168.200.10" type="server" />
                      <SystemNode name="ca01" ip="192.168.200.20" type="server" />
                      <SystemNode name="apps-01" ip="192.168.200.44" type="server" />
                      <SystemNode name="wks-01" ip="192.168.200.101" type="workstation" />
                      <SystemNode name="wks-02" ip="192.168.200.102" type="workstation" />
                      <SystemNode name="ws-eng-01" ip="192.168.200.103" type="workstation" />
                    </div>
                  </div>
                </div>
              </section>

              <section className="panel" id="logs">
                <PanelHeader title="Recent Activity" action="View All Logs →" />
                <div className="activity-table">
                  <div className="activity-head"><span>Time</span><span>System</span><span>Event</span><span>Severity</span></div>
                  {activity.map((row, idx) => (
                    <div className="activity-row" key={idx}>
                      <span><em className="dot"></em>{row[0]}</span>
                      <span>{row[1]}</span>
                      <span>{row[2]}</span>
                      <span><em className="dot"></em>{row[3]}</span>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <div className="right-stack">
              <section className="panel health-panel">
                <PanelHeader title="System Health" action="View All →" />
                <HealthRow icon="▤" label="Domain Controllers" />
                <HealthRow icon="⚙" label="Certificate Services" />
                <HealthRow icon="◇" label="Application Services" />
                <HealthRow icon="▣" label="Workstations" />
                <HealthRow icon="◎" label="External Portal (DMZ)" />
              </section>

              <section className="panel utilization">
                <PanelHeader title="Resource Utilization" action="Last 24 Hours" />
                <div className="gauges">
                  <Gauge value="32" label="CPU" cls="blue" />
                  <Gauge value="48" label="Memory" cls="green" />
                  <Gauge value="61" label="Disk" cls="yellow" />
                </div>
              </section>

              <section className="panel announcements">
                <PanelHeader title="Announcements" action="View All →" />
                {announcements.map((a, idx) => (
                  <div className={`announcement ${a[0]}`} key={idx}>
                    <div className="announce-icon">▣</div>
                    <div className="announce-copy"><b>{a[1]}</b><span>{a[2]}</span></div>
                    <time>{a[3]}</time>
                  </div>
                ))}
              </section>
            </div>
          </section>
        </div>

        <footer className="footer">
          <div className="footer-brand">◈ DEIMUSTECH <span>INTERNAL OPERATIONS</span></div>
          <div>IT Support &nbsp; | &nbsp; Security &nbsp; | &nbsp; Acceptable Use &nbsp; | &nbsp; Privacy</div>
        </footer>
      </main>
    </div>
  );
}

function Metric({ icon, number, title, detail, tone }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}>{icon}</div>
      <div><div className="metric-number">{number}</div><div className="metric-title">{title}</div><div className="metric-detail">{detail}</div></div>
    </div>
  );
}

function PanelHeader({ title, subtitle, action }) {
  return (
    <div className="panel-header">
      <div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>
      {action && <span className="panel-action">{action}</span>}
    </div>
  );
}

function SystemNode({ name, ip, type }) {
  return (
    <div className="sys-node">
      <div className={`sys-icon ${type}`}>{type === 'server' ? '▤' : '▣'}<em></em></div>
      <b>{name}</b>
      <small>{ip}</small>
    </div>
  );
}

function HealthRow({ icon, label }) {
  return (
    <div className="health-row">
      <span className="health-icon">{icon}</span>
      <span>{label}</span>
      <span className="spark">⌁⌁⌁⌁</span>
      <b><em></em>Operational</b>
    </div>
  );
}

function Gauge({ value, label, cls }) {
  return (
    <div className="gauge-wrap">
      <div className={`gauge ${cls}`} style={{'--pct': value}}><span>{value}%</span></div>
      <div>{label}</div>
    </div>
  );
}
