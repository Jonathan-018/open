function App() {
  document.title = "Holloway Systems | Technology That Keeps Business Moving";

  const services = [
    {
      icon: "▦",
      title: "Enterprise Software",
      text: "Practical business applications designed for reliability, integration, and long-term support."
    },
    {
      icon: "▤",
      title: "Managed Infrastructure",
      text: "Reliable infrastructure services that help organizations stay available, connected, and productive."
    },
    {
      icon: "☁",
      title: "Cloud Services",
      text: "Modern cloud architecture and migration support built around real operational requirements."
    },
    {
      icon: "◇",
      title: "Technical Consulting",
      text: "Experienced engineers helping teams modernize systems, solve complex problems, and plan what comes next."
    }
  ];

  const articles = [
    {
      tag: "INFRASTRUCTURE",
      title: "Modernizing Legacy Infrastructure",
      text: "A practical approach to improving reliability without disrupting critical business operations.",
      date: "Mar 12, 2026"
    },
    {
      tag: "CLOUD",
      title: "Building Resilient Hybrid Environments",
      text: "Design considerations for organizations balancing on-premises systems with modern cloud services.",
      date: "Feb 28, 2026"
    },
    {
      tag: "OPERATIONS",
      title: "Improving Application Delivery Workflows",
      text: "Reducing friction between engineering, operations, and the applications they support.",
      date: "Feb 14, 2026"
    }
  ];

  return (
    <div className="site">
      <header className="header">
        <div className="header-inner">
          <a className="brand" href="#">
            <div className="brand-mark">H</div>
            <div>
              <div className="brand-name">HOLLOWAY</div>
              <div className="brand-sub">SYSTEMS</div>
            </div>
          </a>

          <nav>
            <a className="active" href="#">Home</a>
            <a href="#services">Services</a>
            <a href="#insights">Insights</a>
            <a href="#company">Company</a>
            <a href="#contact">Contact</a>
          </nav>

          <div className="search">⌕</div>
        </div>
      </header>

      <section className="hero">
        <div className="hero-grid"></div>
        <div className="hero-glow"></div>

        <div className="hero-inner">
          <div className="hero-copy">
            <div className="eyebrow">TECHNOLOGY THAT KEEPS BUSINESS MOVING</div>
            <h1>Practical Technology.<br/>Built for What’s Next.</h1>
            <p>
              Holloway Systems helps organizations modernize applications,
              infrastructure, and cloud operations without losing sight of
              reliability, security, or the people who depend on them.
            </p>

            <div className="hero-actions">
              <button onClick={() => document.getElementById('services').scrollIntoView({behavior:'smooth'})}>
                Explore Our Services →
              </button>
              <button className="secondary" onClick={() => document.getElementById('contact').scrollIntoView({behavior:'smooth'})}>
                Contact Us
              </button>
            </div>
          </div>

          <div className="hero-art" aria-hidden="true">
            <div className="art-message">PEOPLE<br/>IDEAS<br/>INFRASTRUCTURE<br/><b>A MORE RELIABLE<br/>TOMORROW</b></div>
          </div>
        </div>
      </section>

      <main>
        <section className="services" id="services">
          {services.map((s, i) => (
            <article className="service-card" key={i}>
              <div className="service-icon">{s.icon}</div>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
              <a href="#contact">Learn More →</a>
            </article>
          ))}
        </section>

        <section className="insights-wrap" id="insights">
          <div className="section-heading">
            <div>
              <span>FROM HOLLOWAY SYSTEMS</span>
              <h2>Latest Insights</h2>
            </div>
            <a href="#insights">View All Articles →</a>
          </div>

          <div className="insights">
            {articles.map((a, i) => (
              <article className="article-card" key={i}>
                <div className={`article-image image-${i+1}`}></div>
                <div className="article-copy">
                  <div className="article-tag">{a.tag}</div>
                  <h3>{a.title}</h3>
                  <p>{a.text}</p>
                  <time>{a.date}</time>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="company" id="company">
          <div>
            <span className="small-label">ABOUT HOLLOWAY SYSTEMS</span>
            <h2>Technology with a practical purpose.</h2>
            <p>
              We work with growing organizations that need dependable systems,
              responsive support, and engineering teams that understand how
              technology affects day-to-day operations.
            </p>
          </div>

          <div className="stats">
            <div><strong>15+</strong><span>Years in Technology Services</span></div>
            <div><strong>24/7</strong><span>Managed Operations Support</span></div>
            <div><strong>98%</strong><span>Customer Retention</span></div>
          </div>
        </section>
      </main>

      <footer id="contact">
        <div className="footer-main">
          <div className="footer-brand">
            <div className="brand">
              <div className="brand-mark">H</div>
              <div>
                <div className="brand-name">HOLLOWAY</div>
                <div className="brand-sub">SYSTEMS</div>
              </div>
            </div>
            <p>Technology that keeps business moving.</p>
          </div>

          <div className="footer-col">
            <h4>Services</h4>
            <span>Enterprise Software</span>
            <span>Managed Infrastructure</span>
            <span>Cloud Services</span>
            <span>Technical Consulting</span>
          </div>

          <div className="footer-col">
            <h4>Company</h4>
            <span>About</span>
            <span>Careers</span>
            <span>Insights</span>
            <span>Contact</span>
          </div>

          <div className="footer-col contact-col">
            <h4>Contact</h4>
            <span>info@hollowaysystems.com</span>
            <span>Austin, TX</span>
            <span>Mon–Fri, 8:00 AM–6:00 PM</span>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© 2026 Holloway Systems. All rights reserved.</span>
          <span>Privacy &nbsp; | &nbsp; Terms &nbsp; | &nbsp; Accessibility</span>
        </div>
      </footer>
    </div>
  );
}
